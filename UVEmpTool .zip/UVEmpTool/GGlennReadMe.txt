|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||READ ME|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||

Glenngineering Soft LLC. All Rights Reserved. ** Fictional Company **

|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||GUI|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
Main Page Display

	Custom UVU Graphic

	All Employees
		- ID (Restricted to 5 digits)
		- Full Name (First Name, Middle Initial, Last Name)

	Four Employee Types

	Salary - Monthly Salary
	Hourly - Hourly Salary
	Sales - Comission, Sales, Salary
	Contract - Contract Salary, Agency

Advanced Page Display - Seperate Tab

	Maritial Status
	Department
	Title
	Starting Date

	Employee Benefits List

	Employee Course Education List
	
|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||Features|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||

File - New = Erase Current database, does not delete database file if the file has been saved to a location
File - Open = Add a database from file to the current database, does not delete any currently input employees
File - Save = Save the current database to a location

Tools - Add New Employee = Adds a new employee, repetition of ID will not be added
Tools - Edit Current Employee = Allows the editing of all the currently selected employees data. The ID can't change
Tools - Remove Current Employee = Allows the removal of the current employee. Reminder: Removing all data of history of employment is a federal crime.

Tools - Find Employee - By Last Name = Sets the current employee to the first employee with a matching lastname
Tools - Find Employee - By ID = Sets the current employee to the employee with a matching ID if found

Tools - Advanced Tab Tools - Edit Simple Data = Allows the editing of the current employee's marital status, department, title, and starting date

Tools - Advanced Tab Tools - Benefits - Add Benefit = Adds a benefit to the list of employee benefits
Tools - Advanced Tab Tools - Benefits - Remove Benefit = Removes a benefit from the list of employee benefits

Tools - Advanced Tab Tools - Classes - Add Course = Adds a Course to the list of employee courses
Tools - Advanced Tab Tools - Classes - Remove Course = Removes a Course from the list of employee courses

Tools - Advanced Tab Tools - Calculations - Education Agreement = Checks if the current employee is eligble for credit hour cost reimbursement